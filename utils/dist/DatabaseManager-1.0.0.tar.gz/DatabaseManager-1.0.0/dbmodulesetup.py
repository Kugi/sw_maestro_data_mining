__author__ = 'kugi'



from distutils.core import setup

setup(
    name    = 'DatabaseManager',
    version = '1.0.0',
    py_modules = ['DatabaseManager'],
    author = 'kugi',
    author_email = 'kugipark@gmail.com',
    url = 'http://www.kugistory.net',
    description = 'postgresql DB manager for swm4th-buzzni'
)